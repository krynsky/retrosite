# microsoft.com visual timeline draft

This draft is generated from Wayback Machine capture discovery. Screenshot rendering, visual era grouping, and tech-stack annotation are the next pipeline steps.

- Domain: microsoft.com
- Captures found: 1704
- Candidate eras: 66
- Screenshots rendered: 28
- Selected entries: 10
- Archive range: 1996-2025
- Status: draft
- Generated: 2026-05-04T03:07:02.475Z

## How this timeline was created

- URL variants queried: 6
- Captures found: 1704
- Years spanned: 21
- Candidates selected: 66
- Screenshots attempted: 75
- Usable screenshots: 21
- Weak screenshots: 7
- Failed screenshots: 41
- Replacements used: 9
- Eligible entries: 28
- Final timeline entries: 10
- Years represented: 10 of 21
- Years with weak-only captures: 1

## Timeline

### 1999-04-29: 1999 candidate homepage

![1999-04-29 1999 candidate homepage](screenshots/01-1999-04-29-1999-candidate-homepage.png)

- Tech stack: Classic ASP
- Source: [Wayback capture](https://web.archive.org/web/19990429044155if_/http://www.microsoft.com:80/)



### 2000-09-13: 2000 candidate homepage

![2000-09-13 2000 candidate homepage](screenshots/02-2000-09-13-2000-candidate-homepage.png)

- Tech stack: Classic ASP
- Source: [Wayback capture](https://web.archive.org/web/20000913215055if_/http://www.microsoft.com:80/)



### 2001-10-11: 2001 candidate homepage

![2001-10-11 2001 candidate homepage](screenshots/03-2001-10-11-2001-candidate-homepage.png)

- Tech stack: Classic ASP
- Source: [Wayback capture](https://web.archive.org/web/20011011153827if_/http://www.microsoft.com:80/)



### 2002-09-14: 2002 candidate homepage

![2002-09-14 2002 candidate homepage](screenshots/04-2002-09-14-2002-candidate-homepage.png)

- Tech stack: Classic ASP
- Source: [Wayback capture](https://web.archive.org/web/20020914010551if_/http://www.microsoft.com:80/)



### 2003-06-24: 2003 candidate homepage

![2003-06-24 2003 candidate homepage](screenshots/05-2003-06-24-2003-candidate-homepage.png)

- Tech stack: Classic ASP
- Source: [Wayback capture](https://web.archive.org/web/20030624112341if_/http://microsoft.com:80/)



### 2004-08-23: 2004 candidate homepage

![2004-08-23 2004 candidate homepage](screenshots/06-2004-08-23-2004-candidate-homepage.png)

- Tech stack: Classic ASP
- Source: [Wayback capture](https://web.archive.org/web/20040823174322if_/http://www.microsoft.com/)



### 2005-08-15: 2005 candidate homepage

![2005-08-15 2005 candidate homepage](screenshots/07-2005-08-15-2005-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20050815075617if_/http://www.microsoft.com:80/)



### 2006-06-05: 2006 candidate homepage

![2006-06-05 2006 candidate homepage](screenshots/08-2006-06-05-2006-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20060605141858if_/http://www.microsoft.com/)



### 2024-12-31: 2024 candidate homepage

![2024-12-31 2024 candidate homepage](screenshots/09-2024-12-31-2024-candidate-homepage.png)

- Tech stack: jQuery 1.9.1.
- Source: [Wayback capture](https://web.archive.org/web/20241231082124if_/https://www.microsoft.com/)



### 2025-02-15: 2025 candidate homepage

![2025-02-15 2025 candidate homepage](screenshots/10-2025-02-15-2025-candidate-homepage.png)

- Tech stack: jQuery 1.9.1.
- Source: [Wayback capture](https://web.archive.org/web/20250215211213if_/https://www.microsoft.com/)



