# twitter.com visual timeline draft

This draft is generated from Wayback Machine capture discovery. Screenshot rendering, visual era grouping, and tech-stack annotation are the next pipeline steps.

- Domain: twitter.com
- Captures found: 4098
- Candidate eras: 41
- Screenshots rendered: 20
- Selected entries: 8
- Archive range: 2001-2018
- Status: draft
- Generated: 2026-05-08T17:22:16.138Z

## How this timeline was created

- URL variants queried: 6
- Captures found: 4098
- Years spanned: 12
- Candidates selected: 41
- Screenshots attempted: 41
- Usable screenshots: 11
- Weak screenshots: 9
- Failed screenshots: 0
- Replacements used: 0
- Eligible entries: 20
- Final timeline entries: 8
- Years represented: 8 of 12
- Years with weak-only captures: 1

## Timeline

### 2001-03-02: 2001 candidate homepage

![2001-03-02 2001 candidate homepage](screenshots/01-2001-03-02-2001-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20010302103333if_/http://www.twitter.com:80/)



### 2006-11-18: 2006 candidate homepage

![2006-11-18 2006 candidate homepage](screenshots/02-2006-11-18-2006-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20061118063054if_/http://twitter.com/)



### 2007-07-18: 2007 candidate homepage

![2007-07-18 2007 candidate homepage](screenshots/03-2007-07-18-2007-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20070718185757if_/http://twitter.com/)



### 2008-05-12: 2008 candidate homepage

![2008-05-12 2008 candidate homepage](screenshots/04-2008-05-12-2008-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20080512173534if_/http://twitter.com/)



### 2009-06-16: 2009 candidate homepage

![2009-06-16 2009 candidate homepage](screenshots/05-2009-06-16-2009-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20090616182632if_/http://twitter.com/)



### 2010-01-01: 2010 candidate homepage

![2010-01-01 2010 candidate homepage](screenshots/06-2010-01-01-2010-candidate-homepage.png)

- Tech stack: jQuery
- Source: [Wayback capture](https://web.archive.org/web/20100101041725if_/http://twitter.com/)



### 2013-01-01: 2013 candidate homepage

![2013-01-01 2013 candidate homepage](screenshots/07-2013-01-01-2013-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20130101000700if_/https://twitter.com/)



### 2018-01-01: 2018 candidate homepage

![2018-01-01 2018 candidate homepage](screenshots/08-2018-01-01-2018-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20180101001032if_/https://twitter.com/)



