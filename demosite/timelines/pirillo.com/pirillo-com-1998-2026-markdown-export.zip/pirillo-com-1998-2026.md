# pirillo.com visual timeline draft

This draft is generated from Wayback Machine capture discovery. Screenshot rendering, visual era grouping, and tech-stack annotation are the next pipeline steps.

- Domain: pirillo.com
- Captures found: 183
- Candidate eras: 52
- Screenshots rendered: 56
- Selected entries: 13
- Archive range: 1998-2026
- Status: draft
- Generated: 2026-05-04T19:02:59.527Z

## How this timeline was created

- URL variants queried: 6
- Captures found: 183
- Years spanned: 18
- Candidates selected: 52
- Screenshots attempted: 57
- Usable screenshots: 46
- Weak screenshots: 10
- Failed screenshots: 1
- Replacements used: 5
- Eligible entries: 56
- Final timeline entries: 13
- Years represented: 13 of 18
- Years with weak-only captures: 1

## Timeline

### 1998-12-05: 1998 candidate homepage

![1998-12-05 1998 candidate homepage](screenshots/01-1998-12-05-1998-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/19981205124727if_/http://www.pirillo.com:80/)



### 2002-06-03: 2002 candidate homepage

![2002-06-03 2002 candidate homepage](screenshots/02-2002-06-03-2002-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20020603094213if_/http://pirillo.com:80/)



### 2003-04-11: 2003 candidate homepage

![2003-04-11 2003 candidate homepage](screenshots/03-2003-04-11-2003-candidate-homepage.png)

- Tech stack: Classic ASP
- Source: [Wayback capture](https://web.archive.org/web/20030411124601if_/http://pirillo.com:80/)



### 2004-08-28: 2004 candidate homepage

![2004-08-28 2004 candidate homepage](screenshots/04-2004-08-28-2004-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20040828105822if_/http://www.pirillo.com:80/)



### 2006-08-14: 2006 candidate homepage

![2006-08-14 2006 candidate homepage](screenshots/05-2006-08-14-2006-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20060814185508if_/http://www.pirillo.com:80/)



### 2008-04-18: 2008 candidate homepage

![2008-04-18 2008 candidate homepage](screenshots/06-2008-04-18-2008-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20080418151919if_/http://www.pirillo.com:80/)



### 2011-07-04: 2011 candidate homepage

![2011-07-04 2011 candidate homepage](screenshots/07-2011-07-04-2011-candidate-homepage.png)

- Tech stack: jQuery
- Source: [Wayback capture](https://web.archive.org/web/20110704095607if_/http://pirillo.com/)



### 2012-06-08: 2012 candidate homepage

![2012-06-08 2012 candidate homepage](screenshots/08-2012-06-08-2012-candidate-homepage.png)

- Tech stack: jQuery
- Source: [Wayback capture](https://web.archive.org/web/20120608091801if_/http://www.pirillo.com:80/)



### 2015-09-05: 2015 candidate homepage

![2015-09-05 2015 candidate homepage](screenshots/09-2015-09-05-2015-candidate-homepage.png)

- Tech stack: WordPress 4.2.3, Twentyfourteen theme, Jetpack · jQuery
- Source: [Wayback capture](https://web.archive.org/web/20150905075205if_/http://pirillo.com/)



### 2016-08-01: 2016 candidate homepage

![2016-08-01 2016 candidate homepage](screenshots/10-2016-08-01-2016-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20160801110912if_/https://www.pirillo.com/)



### 2017-04-22: 2017 candidate homepage

![2017-04-22 2017 candidate homepage](screenshots/11-2017-04-22-2017-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20170422171546if_/https://www.pirillo.com/)



### 2025-05-11: 2025 candidate homepage

![2025-05-11 2025 candidate homepage](screenshots/12-2025-05-11-2025-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20250511100917if_/https://pirillo.com/)



### 2026-05-04: 2026 candidate homepage

![2026-05-04 2026 candidate homepage](screenshots/13-2026-05-04-2026-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20260504150400if_/https://pirillo.com/)



