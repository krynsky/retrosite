# nytimes.com visual timeline draft

This draft is generated from Wayback Machine capture discovery. Screenshot rendering, visual era grouping, and tech-stack annotation are the next pipeline steps.

- Domain: nytimes.com
- Captures found: 2000
- Candidate eras: 38
- Screenshots rendered: 26
- Selected entries: 10
- Archive range: 1996-2007
- Status: draft
- Generated: 2026-05-08T16:05:17.723Z

## How this timeline was created

- URL variants queried: 6
- Captures found: 2000
- Years spanned: 10
- Candidates selected: 38
- Screenshots attempted: 39
- Usable screenshots: 25
- Weak screenshots: 1
- Failed screenshots: 3
- Replacements used: 1
- Eligible entries: 26
- Final timeline entries: 10
- Years represented: 10 of 10
- Years with weak-only captures: 0

## Timeline

### 1996-12-19: 1996 candidate homepage

![1996-12-19 1996 candidate homepage](screenshots/01-1996-12-19-1996-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/19961219002950if_/http://www.nytimes.com:80/)



### 1997-03-03: 1997 candidate homepage

![1997-03-03 1997 candidate homepage](screenshots/02-1997-03-03-1997-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/19970303103041if_/http://www1.nytimes.com:80/)



### 1998-12-12: 1998 candidate homepage

![1998-12-12 1998 candidate homepage](screenshots/03-1998-12-12-1998-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/19981212034354if_/http://www2.nytimes.com:80/)



### 1999-01-25: 1999 candidate homepage

![1999-01-25 1999 candidate homepage](screenshots/04-1999-01-25-1999-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/19990125104746if_/http://www11.nytimes.com:80/)



### 2000-11-09: 2000 candidate homepage

![2000-11-09 2000 candidate homepage](screenshots/05-2000-11-09-2000-candidate-homepage.png)

- Tech stack: Classic ASP
- Source: [Wayback capture](https://web.archive.org/web/20001109144000if_/http://www1.nytimes.com:80/)



### 2001-09-04: 2001 candidate homepage

![2001-09-04 2001 candidate homepage](screenshots/06-2001-09-04-2001-candidate-homepage.png)

- Tech stack: Classic ASP
- Source: [Wayback capture](https://web.archive.org/web/20010904140155if_/http://www.nytimes.com:80/)



### 2002-01-23: 2002 candidate homepage

![2002-01-23 2002 candidate homepage](screenshots/07-2002-01-23-2002-candidate-homepage.png)

- Tech stack: Classic ASP
- Source: [Wayback capture](https://web.archive.org/web/20020123003613if_/http://nytimes.com:80/)



### 2003-02-08: 2003 candidate homepage

![2003-02-08 2003 candidate homepage](screenshots/08-2003-02-08-2003-candidate-homepage.png)

- Tech stack: Classic ASP
- Source: [Wayback capture](https://web.archive.org/web/20030208085205if_/http://www10.nytimes.com:80/)



### 2006-01-01: 2006 candidate homepage

![2006-01-01 2006 candidate homepage](screenshots/09-2006-01-01-2006-candidate-homepage.png)

- Tech stack: Static HTML
- Source: [Wayback capture](https://web.archive.org/web/20060101080848if_/http://nytimes.com:80/)



### 2007-01-01: 2007 candidate homepage

![2007-01-01 2007 candidate homepage](screenshots/10-2007-01-01-2007-candidate-homepage.png)

- Tech stack: Classic ASP
- Source: [Wayback capture](https://web.archive.org/web/20070101154858if_/http://www.nytimes.com:80/)



